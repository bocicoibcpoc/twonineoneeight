# truffle-init-bare

Barebones Truffle project.
